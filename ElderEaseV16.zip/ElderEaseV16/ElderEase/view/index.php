<div id="welcome-div">
    <h3>Bridging Generations with Care and Compassion</h3>
    <h1>Elder Ease</h1>
    <p>ElderEase is a haven for seniors, made possible by generous donations and dedicated volunteers. Our mission is simple: to provide a loving home for the elderly, filled with warmth, companionship, and support. Join us in making a difference in the lives of our cherished seniors.</p>

</div>