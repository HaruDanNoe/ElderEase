

<div class="about">
<div class="responsive-container-block bigContainer">
  <div class="responsive-container-block Container">
    <p class="text-blk heading">
      About Us
    </p>
    <p class="text-blk subHeading">
    ElderEase is a compassionate and community-driven organization dedicated to providing a nurturing home for the elderly. Founded with a deep sense of responsibility and a commitment to honoring the wisdom and contributions of our seniors, ElderEase strives to create a supportive environment where elderly individuals can age with dignity, comfort, and companionship.

</p>

    
    </div>
  </div>
</div>


</div>