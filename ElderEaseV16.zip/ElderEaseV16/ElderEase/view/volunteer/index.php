<?php
  
include_once 'model/class.v.php';
$volunteer = new Volunteer();

?>
<h3>Apply for Volunteer</h3>
<div id="form-block">

    <form method="POST" action="controller/pvolunteer.php?action=new" enctype="multipart/form-data" onsubmit="return validateForm()">
        <div id="form-block-half">
            
            <label for="vp_name">Full Name</label>
            <input type="text" id="fullname" class="input" name="vp_name" placeholder="Your full name.." required>

            <label for="vp_phonenumber">Phone Number</label>
            <input type="text" id="phone" class="input" name="vp_phonenumber" placeholder="Your phone number..">

            <label for="vp_email">Email</label>
            <input type="email" id="email" class="input" name="vp_email" placeholder="Your email.." required>

            <label for="vp_password">Password</label>
            <input type="password" id="password" class="input" name="vp_password" placeholder="Your password.." required>
        </div>
        <div id="form-block-half">
            <label for="vp_biodata">Bio data File upload</label>
            <input type="file" id="biodata" class="input" name="vpbiodata" required>
        </div>
        <div id="button-block">
            <input type="submit" value="Apply">
        </div>
    </form>

</div>

<script>
    function validateForm() {
        var fullname    = document.getElementById("fullname").value;
        var phone       = document.getElementById("phone").value;
        var email       = document.getElementById("email").value;
        var password    = document.getElementById("password").value;
        var biodata     = document.getElementById("biodata").value;

        // Regular expression to check if password contains both characters and numbers
        var passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d).{8,}$/;

        if (fullname == "" || phone == "" || email == "" || password == "" || biodata == "") {
            alert("All fields must be filled out");
            return false;
        } else if (!passwordRegex.test(password)) {
            alert("Password must contain at least one character and one number, and be at least 8 characters long");
            return false;
        } else {
            alert("Successfully applied! Results will be sent to your email");
            return true;
        }
    }
</script>
