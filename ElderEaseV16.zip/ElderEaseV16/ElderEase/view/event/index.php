<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start(); // Start the session if not already started
}

include 'model/class.event.php';
include 'model/class.v.php';
include 'model/class.e.v.php'; // Include the EventApplication class

$events     = new Event();
$volunteer  = new Volunteer();

// Define or initialize the $page variable
$page = isset($_GET['page']) ? $_GET['page'] : '';

if($page === 'volunteer') {
    // Redirect back to volunteer page if user is already logged in
    if(isset($_SESSION['vp_id'])) {
        header('Location: index.php?page=volunteer');
        exit();
    }
}

?>

<div class="welcome-div">
    <div class="topic-text">
        <h1>Events to Apply.</h1>
            <p>Events and Schedule</p></div>

        <div class="card-container">
            <?php
                 $count = 1;
                    if ($events->list_events() != false) {
                        foreach ($events->list_events() as $value) {
                            extract($value);

                    $event_volunteer = new EventVolunteer();
                    $num_applicants = $event_volunteer->get_num_applicants($e_id);
            ?>

            <div class="card">
                <div class="card-header"><?php echo $e_description; ?></div>
                <div class="card-body">
                    <p>Date:                <?php echo $e_date; ?></p>
                    <p>Start Time:          <?php echo $e_stime; ?></p>
                    <p>End Time:            <?php echo $e_etime; ?></p>
                    <p>Volunteers Applied:  <?php echo $num_applicants; ?><br></p>
                    <p>Action: 
                        <?php if (isset($_SESSION['vp_id'])) : ?>
                            <a href="">Apply</a>
                        <?php else : ?>
                            <a href="index.php?page=login" onclick="alert('You must apply first.  Click Be a Volunteer');">Apply</a>
                            <?php
                                switch($page){
                                    case 'login':
                                        require_once 'login/index.php';
                                    break; 
                                }
                            ?>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
            <?php
            $count++;
        }
    } else {
        echo "<p>No Record Found.</p>";
    }
    ?>
</div>


</div>