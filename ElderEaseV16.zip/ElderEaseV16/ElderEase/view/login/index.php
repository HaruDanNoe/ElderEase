<?php
include 'model/class.user.login.php';

$user = new User();
$error_message = "";

if(isset($_POST['submit'])) {
    $email = $_POST['useremail'];
    $password = $_POST['password'];

    if($user->check_login($email, $password)) {
        exit();
    } elseif($user->check_volunteer_login($email, $password)) {
        exit();
    } else {
        // If neither regular login nor volunteer login succeeds
        $error_message = "Invalid login credentials or your account hasn't been activated yet"; 
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
</head>
<body>

<div id="login-box">
    <h2>Please login</h2>
    
    <form method="POST" action="" name="login">
        <div class="user-box">
            <input type="email" class="input" required name="useremail"/>
            <label>Email</label>
        </div>
        <div class="user-box">
            <input type="password" class="input" required name="password"/>
            <label>Password</label>
        </div>
        <input class="button" type="submit" name="submit" value="Submit"/>
    </form>
    
    <?php if(!empty($error_message)): ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <br>
    <a href="index.php?page=volunteer">Be a Volunteer!</a>

    <?php
    if(isset($page) && $page === 'volunteer'){
        require_once 'volunteer/index.php';
    }
    ?>
</div>
        
</body>
</html>
