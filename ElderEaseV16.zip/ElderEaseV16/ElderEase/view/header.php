<?php
/* include the class file (global - within application) */
include 'config/config.php';

$page = (isset($_GET['page']) && $_GET['page'] != '') ? $_GET['page'] : '';
$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';
$id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : '';
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ElderEase</title>
    <link rel="icon" type="image/x-icon" href="img/icon/favicon.ico"></head>
<body>
<header class="header">
        <nav class="navi"> 
            <a href="index.php" class="navi-logo">
                <img width="100px" height="auto" src="img/logo/eldereaselogo.png">
            </a>

            <ul class="navi_items">
            <li class="navi_item">
                <a href="index.php" class="navi_link">Home</a>
                <a href="index.php?page=about" class="navi_link">About</a>
                <a href="index.php?page=donate" class="navi_link">Donate</a>
                <a href="index.php?page=event" class="navi_link">Event</a>
                <!-- <a href="index.php?page=volunteer" class="navi_link">Be a Volunteer!</a> -->

                <div class="navv">
                <a class="button" href="index.php?page=login">Log In</a>     
                </div>
              </li>
        </ul>
            
   
        </nav>

        <?php
      switch($page){
                case 'about':
                    require_once 'about/index.php';
                break; 
               
                case 'donate':
                    require_once 'donate/index.php';
                    break;
                case 'volunteer':
                    require_once 'volunteer/index.php';
                    break;
                case 'event':
                    require_once 'event/index.php';
                    break;
                case 'login':
                    require 'login/index.php';
                break; 
                default:
                    require_once 'index.php'; // Include index content if no specific page is accessed
                break; 
            }
    ?>
    </header>

  
    
</body>
</html>
