<?php

    include 'model/class.donations.php';

    $donations = new Donations();
?>



<div class="donation">
    

  <div class="container">
    <div class="content">
      <div class="left-side">
        <div class="address details">
          <i class="fas fa-map-marker-alt"></i>
          <div class="topic">Address</div>
          <div class="text-one">Saturn St., Bacolod City</div>
          <div class="text-two">Negros Occidental</div>
        </div>
        <div class="phone details">
          <i class="fas fa-phone-alt"></i>
          <div class="topic">Payment Methods</div>

          <div class="topic">Gcash Details</div>
          <div class="text-one">Eldear Ease</div>
          <div class="text-two">+0096 3434 5678</div>
        </div>
        <div class="phone details">
          <i class="fas fa-phone-alt"></i>
          <div class="topic">Paymaya Details</div>
          <div class="text-one">Eldear Ease</div>
          <div class="text-two">+0096 3434 5678</div>
        </div>

        <div class="email details">
          <i class="fas fa-envelope"></i>
          <div class="topic">Email</div>
          <div class="text-one">elderease@gmail.com</div>
          <div class="text-two">info.eldeareaseb@gmail.com</div>
        </div>
      </div>
      <div class="right-side">
        
       <div id="form-block">
       <div class="topic-text"><h3>Be a Donor</h3></div>
        <p>"Caring for Our Elders – Support Them Today!"</p>
       
    <form action="controller/pdonation.php?action=new" method="POST" enctype="multipart/form-data">
    
    <div id="form-block-half">
            
        <div class="input-box">
            <input type="text" id="d_name" name="d_name" required placeholder="Enter your fullname">
        </div>
            
        <div class="input-box">
            <input type="email" id="d_email" name="d_email" required placeholder="Enter your email">
        </div>

        <div class="input-box">
            <input type="tel" id="d_phonenumber" name="d_phonenumber" required placeholder="Enter your phone number">
        </div>

        <div class="input-box">
            <textarea id="d_comment" name="d_comment" rows="4" cols="50" placeholder="Comment"></textarea>
        </div>

           </div>
        <div id="form-block-half">

        <div class="input-box">
            <input type="number" id="d_amount" name="d_amount" step="0.01" min="0" required placeholder="Donation Amount">
        </div>

        
            <label for="image"> Attach a receipt from your GCash or PayMaya transaction.</label>
            <input type="file" id="file" class="input" name="d_pmethod" accept=".jpg, .jpeg, .png" required placeholder="Upload Receipt">
        </div>

        <div id="button-block">
            <button  class="button" type="submit">Submit Donation</button>
        </div>
    </form>
</div>
    </div>
    </div>
  </div>

</div>