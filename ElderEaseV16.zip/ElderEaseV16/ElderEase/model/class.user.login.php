<?php
class User{
    // Database connection details
	private $DB_SERVER = '172.16.0.214';
    private $DB_USERNAME = 'group46';
    private $DB_PASSWORD = '123456';
    private $DB_DATABASE = 'group46';
    private $conn;

    // Constructor to establish database connection
	public function __construct(){
		$this->conn = new PDO("mysql:host=".$this->DB_SERVER.";dbname=".$this->DB_DATABASE,$this->DB_USERNAME,$this->DB_PASSWORD);
	}
	

   
    // Method to get user ID by email
	function get_user_id($email){
		$sql="SELECT user_id FROM tbl_user WHERE user_email = :email";	
		$q = $this->conn->prepare($sql);
		$q->execute(['email' => $email]);
		$user_id = $q->fetchColumn();
		return $user_id;
	}

    
    // Method to check if a user is logged in
	function get_session(){
		if(isset($_SESSION['login']) && $_SESSION['login'] == true){
			return true;
		}else{
			return false;
		}
	}

    public function check_login($email, $password) {
        $sql = "SELECT user_id, user_role, user_password FROM tbl_user WHERE user_email = :email"; 
        $q = $this->conn->prepare($sql);
        $q->execute(['email' => $email]);
        $user = $q->fetch(PDO::FETCH_ASSOC);
    
        if ($user && password_verify($password, $user['user_password'])) {
            $_SESSION['login']      = true;
            $_SESSION['user_id']    = $user['user_id'];
            $_SESSION['user_email'] = $email;
            $_SESSION['user_role']  = $user['user_role'];
    
            // Construct the URL with user_id parameter
            $redirect_url = '';
            switch ($user['user_role']) {
                case 'Admin':
                    $redirect_url = 'admin/index.php?user_id=' . $user['user_id'];
                    break;
                case 'Volunteer':
                    $redirect_url = 'volunteer/index.php?user_id=' . $user['user_id'];
                    break;
                case 'Finance':
                    $redirect_url = 'finance/index.php?user_id=' . $user['user_id'];
                    break;
                default:
                    $redirect_url = '../index.php?user_id=' . $user['user_id'];
                    break;
            }
    
            // Redirect to the appropriate page with user_id parameter
            header('Location: ' . $redirect_url);
            exit();
        } else {
            return false;
        }
    }
    
    
    public function check_volunteer_login($email, $password) {

        $sql = "SELECT vp_id, vp_password, vp_status FROM tbl_volunteerapplication WHERE vp_email = :email"; 
        
        $q = $this->conn->prepare($sql);
        $q->execute(['email' => $email]);
        $volunteer = $q->fetch(PDO::FETCH_ASSOC);
    
        if ($volunteer && $volunteer['vp_status'] == 1 && password_verify($password, $volunteer['vp_password'])) {
            // Password verification succeeded and volunteer status is approved
            $_SESSION['login']      = true;
            $_SESSION['vp_id']      = $volunteer['vp_id'];
            $_SESSION['vp_email']   = $email;
    
            // Redirect to the volunteer page with volunteer ID as a parameter
            header('Location: volunteer/index.php?vp_id=' . $volunteer['vp_id']);
            exit();
            
        } elseif ($volunteer && $volunteer['vp_status'] == 0) {
            // Volunteer's status is 0, meaning the application is pending
            echo "<script>alert('Your application is still pending. Please wait for 3 business days for approval.');</script>";
        } 
    }
}    

?>
