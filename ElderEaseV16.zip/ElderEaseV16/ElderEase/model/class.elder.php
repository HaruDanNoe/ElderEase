<?php
class Elder{
    // Database connection details
	private $DB_SERVER = '172.16.0.214';
    private $DB_USERNAME = 'group46';
    private $DB_PASSWORD = '123456';
    private $DB_DATABASE = 'group46';
    private $conn;

    // Constructor to establish database connection
	public function __construct(){
		$this->conn = new PDO("mysql:host=".$this->DB_SERVER.";dbname=".$this->DB_DATABASE,$this->DB_USERNAME,$this->DB_PASSWORD);
	}
	
	public function new_elder($p_fullname, $p_gender, $p_age, $p_birthday, $p_status, $p_medicalhistory)
{
    // Prepare the SQL query with correct column names
    $stmt = $this->conn->prepare("INSERT INTO tbl_patients (p_fullname,p_gender, p_age, p_birthday, p_status, p_medicalhistory) VALUES (?, ?, ?, ?, ?, ?)");

    // Wrap the data in an array
    $data = array($p_fullname, $p_gender, $p_age, $p_birthday, $p_status, $p_medicalhistory);

    try {
        // Start a transaction
        $this->conn->beginTransaction();

        // Execute the prepared statement for each set of data
        $stmt->execute($data);

        // Commit the transaction
        $this->conn->commit();
    } catch (PDOException $e) {
        // Rollback the transaction if an error occurs
        $this->conn->rollback();
        throw $e;
    }

    return true;
}

function get_elder($p_id){
    $sql="SELECT * FROM tbl_patients WHERE p_id = :p_id";	
    $q = $this->conn->prepare($sql);
    $q->execute(['p_id' => $p_id]);
    while($r = $q->fetch(PDO::FETCH_ASSOC)){
        $data[]=$r;
    }
    if(empty($data)){
       return false;
    }else{
        return $data;	
    }
}

    // Method to update user information
	public function update_elder($p_fullname, $p_gender, $p_age, $p_birthday, $p_status, $p_medicalhistory, $p_id){
        // Get the current date and time in Asia/Manila timezone
        $NOW = new DateTime('now', new DateTimeZone('Asia/Manila'));
        $NOW = $NOW->format('Y-m-d H:i:s');
    
        // Prepare and execute the SQL statement to update the elder
        $sql = "UPDATE tbl_patients SET p_fullname=:p_fullname, p_gender=:p_gender, p_age=:p_age,p_birthday=:p_birthday, 
                        p_status=:p_status, p_medicalhistory=:p_medicalhistory WHERE p_id=:p_id";
    
        $q = $this->conn->prepare($sql);
    
        $q->execute(array(':p_fullname'=>$p_fullname, ':p_gender'=>$p_gender, ':p_age'=>$p_age, ':p_birthday'=>$p_birthday, ':p_status'=>$p_status, ':p_medicalhistory'=>$p_medicalhistory, ':p_id'=>$p_id));
        return true;
    }
    
    
    // Method to retrieve a list of all users
	public function list_elders(){
		$sql="SELECT * FROM tbl_patients";
		$q = $this->conn->query($sql) or die("failed!");
		while($r = $q->fetch(PDO::FETCH_ASSOC)){
		    $data[]=$r;
		}
		if(empty($data)){
		   return false;
		}else{
			return $data;	
		}
	}

    public function delete_elder($id) {
        $stmt = $this->conn->prepare("DELETE FROM tbl_patients WHERE p_id = ?");
        $stmt->execute([$id]);
        return $stmt->rowCount() > 0;
    }
    
 

   
	
}
?>
