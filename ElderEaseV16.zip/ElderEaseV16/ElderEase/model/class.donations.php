<?php
class Donations {
    // Database connection details
    private $DB_SERVER = '172.16.0.214';
    private $DB_USERNAME = 'group46';
    private $DB_PASSWORD = '123456';
    private $DB_DATABASE = 'group46';
    private $conn;

    // Constructor to establish database connection
    public function __construct() {
        $this->conn = new PDO("mysql:host=".$this->DB_SERVER.";dbname=".$this->DB_DATABASE,$this->DB_USERNAME,$this->DB_PASSWORD);
    }
    
    // Method to create a new donation
    public function new_donation($d_name, $d_email, $d_phonenumber, $d_comment, $d_amount, $d_pmethod) {
        // Get the current date and time in Asia/Manila timezone
        $now = new DateTime('now', new DateTimeZone('Asia/Manila'));
        $now = $now->format('Y-m-d H:i:s');

        // Prepare data for insertion
        $data = [
            [$d_name, $d_email, $d_phonenumber, $d_comment, $d_amount, $d_pmethod, $now],
        ];

        // Prepare and execute the SQL statement to insert the donation
        $stmt = $this->conn->prepare("INSERT INTO tbl_donation (d_name, d_email, d_phonenumber, d_comment, d_amount, d_pmethod, d_datetransaction) VALUES (?, ?, ?, ?, ?, ?, ?)");
        try {
            $this->conn->beginTransaction();
            foreach ($data as $row) {
                $stmt->execute($row);
            }
            $this->conn->commit();
        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }

        return true;
    }

    // Method to list all donations
    public function list_donations() {
        $sql = "SELECT * FROM tbl_donation";
        $q = $this->conn->query($sql);
        $data = [];
        while ($r = $q->fetch(PDO::FETCH_ASSOC)) {
            $data[] = $r;
        }
        return $data;
    }

    public function get_donation($d_id) {
        $sql = "SELECT * FROM tbl_donation WHERE d_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$d_id]);
        $donation = $stmt->fetch(PDO::FETCH_ASSOC);
        return $donation;
    }
}
?>
