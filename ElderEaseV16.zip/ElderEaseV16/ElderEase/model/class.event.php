<?php
class Event{
    private $DB_SERVER = '172.16.0.214';
    private $DB_USERNAME = 'group46';
    private $DB_PASSWORD = '123456';
    private $DB_DATABASE = 'group46';
    private $conn;

    public function __construct(){
        try {
            $this->conn = new PDO("mysql:host=".$this->DB_SERVER.";dbname=".$this->DB_DATABASE,$this->DB_USERNAME,$this->DB_PASSWORD);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Enable error reporting
        } catch (PDOException $e) {
            // Handle connection error
            error_log("Connection failed: " . $e->getMessage());
            // You might want to display a user-friendly message or terminate gracefully here
            exit();
        }
    }
    
    public function new_event($e_date, $e_stime, $e_etime, $e_description){
        // Input validation
        if(empty($e_date) || empty($e_stime) || empty($e_etime) || empty($e_description)){
            return "Date, time, and description are required.";
        }
    
        try {
            $stmt = $this->conn->prepare("INSERT INTO tbl_event (e_date, e_stime, e_etime, e_description) VALUES (?, ?, ?, ?)");
            $stmt->execute([$e_date, $e_stime, $e_etime, $e_description]);
            return ''; // Insertion successful
        } catch (PDOException $e) {
            if ($e->getCode() == '23000') {
                // Duplicate entry error
                return $e->getCode();
            } else {
                // Other PDOException, handle it as needed
                error_log("Error: " . $e->getMessage());
                return false;
            }
        }
    }
    

    public function list_events(){
        try {
            $data = array(); // Initialize an empty array
            $sql = "SELECT * FROM tbl_event";
            $q = $this->conn->query($sql);
            while($r = $q->fetch(PDO::FETCH_ASSOC)){
                $data[] = $r;
            }
            return $data;
        } catch (PDOException $e) {
            error_log("Error: " . $e->getMessage());
            return false;
        }
    }

    public function delete_event($e_id){
        // Input validation
        if(empty($e_id)){
            return "Event ID is required.";
        }

        try {
            $sql = "DELETE FROM tbl_event WHERE e_id = :e_id";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindParam(':e_id', $e_id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->rowCount() > 0; // Return true if rows affected
        } catch (PDOException $e) {
            // Handle error here
            error_log("Error: " . $e->getMessage());
            return false;
        }
    }

    public function count_volunteers_applied($e_id) {
        try {
            $sql = "SELECT COUNT(*) FROM tbl_event_applications WHERE e_id = :e_id";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindParam(':e_id', $e_id, PDO::PARAM_INT);
            $stmt->execute();
            $count = $stmt->fetchColumn();
            return $count;
        } catch (PDOException $e) {
            // Handle error
            error_log("Error counting volunteers applied: " . $e->getMessage());
            return false;   
        }
    }
    
}
?>
