<?php
class User{
    // Database connection details
	private $DB_SERVER = '172.16.0.214';
    private $DB_USERNAME = 'group46';
    private $DB_PASSWORD = '123456';
    private $DB_DATABASE = 'group46';
    private $conn;

    // Constructor to establish database connection
	public function __construct(){
		$this->conn = new PDO("mysql:host=".$this->DB_SERVER.";dbname=".$this->DB_DATABASE,$this->DB_USERNAME,$this->DB_PASSWORD);
	}
	
	public function new_user($user_fname, $user_lname, $user_gender, $user_age, $user_address, $user_phonenumber, $user_role, $user_email, $user_password, $user_confirmpassword) {
		/* Setting Timezone for DB */
		$NOW = new DateTime('now', new DateTimeZone('Asia/Manila'));
		$NOW = $NOW->format('Y-m-d H:i:s');
	
		$stmt = $this->conn->prepare("INSERT INTO tbl_user (user_fname, user_lname, user_gender, user_age, user_address, user_phonenumber, user_role, user_email, user_password, 
									user_confirmpassword, user_date_added, user_time_added) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
	
		try {
			$this->conn->beginTransaction();
			$stmt->execute([$user_fname, $user_lname, $user_gender, $user_age, $user_address, $user_phonenumber, $user_role, $user_email, $user_password, $user_confirmpassword, $NOW, $NOW]);
			$this->conn->commit();
			return true;
		} catch (Exception $e) {
			$this->conn->rollback();
			error_log("Error creating new user: " . $e->getMessage());
			return false;
		}
	}
	
    // Method to update user information
	public function update_user($user_fname, $user_lname, $user_phonenumber, $user_role, $user_email, $user_id) {
		// Get the current date and time in Asia/Manila timezone
		$NOW = new DateTime('now', new DateTimeZone('Asia/Manila'));
		$NOW = $NOW->format('Y-m-d H:i:s');
		
		// Prepare and execute the SQL statement to update the user
		$sql = "UPDATE tbl_user SET user_fname=:user_fname, user_lname=:user_lname, user_phonenumber=:user_phonenumber, user_role=:user_role, user_email=:user_email, user_date_added=:user_date_updated, user_time_added=:user_time_updated WHERE user_id=:user_id";
		$q = $this->conn->prepare($sql);
		$q->execute(array(':user_fname'=>$user_fname, ':user_lname'=>$user_lname, ':user_phonenumber'=>$user_phonenumber, ':user_role'=>$user_role, ':user_email'=>$user_email, ':user_date_updated'=>$NOW, ':user_time_updated'=>$NOW, ':user_id'=>$user_id));
		return true;
	}
	

    // Method to get user ID by email
	
    function get_user($user_id){
		$sql="SELECT * FROM tbl_user WHERE user_id = :user_id";	
		$q = $this->conn->prepare($sql);
		$q->execute(['user_id' => $user_id]);
		while($r = $q->fetch(PDO::FETCH_ASSOC)){
		    $data[]=$r;
		}
		if(empty($data)){
		   return false;
		}else{
			return $data;	
		}
	}

    function get_user_id($user_email){
		$sql="SELECT user_id FROM tbl_user WHERE user_email = :user_email";	
		$q = $this->conn->prepare($sql);
		$q->execute(['user_email' => $user_email]);
		$user_id = $q->fetchColumn();
		return $user_id;
	}
	function get_user_email($user_id){
		$sql="SELECT user_email FROM tbl_user WHERE user_id = :user_id";	
		$q = $this->conn->prepare($sql);
		$q->execute(['user_id' => $user_id]);
		$user_email = $q->fetchColumn();
		return $user_email;
	}
	function get_user_firstname($user_id){
		$sql="SELECT user_fname FROM tbl_user WHERE user_id = :user_id";	
		$q = $this->conn->prepare($sql);
		$q->execute(['user_id' => $user_id]);
		$user_firstname = $q->fetchColumn();
		return $user_firstname;
	}
	function get_user_lastname($user_id){
		$sql="SELECT user_lname FROM tbl_user WHERE user_id = :user_id";	
		$q = $this->conn->prepare($sql);
		$q->execute(['user_id' => $user_id]);
		$user_lastname = $q->fetchColumn();
		return $user_lastname;
	}
	function get_user_address($user_id){
		$sql="SELECT user_address FROM tbl_user WHERE user_id = :user_id";	
		$q = $this->conn->prepare($sql);
		$q->execute(['user_id' => $user_id]);
		$user_lastname = $q->fetchColumn();
		return $user_lastname;
	}
	function get_user_phonenumber($user_id){
		$sql="SELECT user_phonenumber FROM tbl_user WHERE user_id = :user_id";	
		$q = $this->conn->prepare($sql);
		$q->execute(['user_id' => $user_id]);
		$user_lastname = $q->fetchColumn();
		return $user_lastname;
	}
	function get_user_role($user_id){
		$sql="SELECT user_role FROM tbl_user WHERE user_id = :user_id";	
		$q = $this->conn->prepare($sql);
		$q->execute(['user_id' => $user_id]);
		$user_lastname = $q->fetchColumn();
		return $user_lastname;
	}
	

	    // Method to check if a user is logged in

	function get_session(){
		if(isset($_SESSION['login']) && $_SESSION['login'] == true){
			return true;
		}else{
			return false;
		}
	}

	    // Method to retrieve a list of all users
		public function list_users(){
			$sql="SELECT * FROM tbl_user";
			$q = $this->conn->query($sql) or die("failed!");
			while($r = $q->fetch(PDO::FETCH_ASSOC)){
				$data[]=$r;
			}
			if(empty($data)){
			   return false;
			}else{
				return $data;	
			}
		}
	


    // Method to check user login credentials
	public function check_login($email,$password, $access){
		$sql = "SELECT count(*) FROM tbl_user WHERE user_email = :email AND user_password = :password AND user_access = :access"; 
		$q = $this->conn->prepare($sql);
		$q->execute(['email' => $email,'password' => $password, 'access' =>  $access ]);
		$number_of_rows = $q->fetchColumn();

		if($number_of_rows == 1){
			$_SESSION['login']=true;
			$_SESSION['user_email']=$email;
			return true;
		}else{
			return false;
		}
	}

	public function delete_user($user_id){
		// Prepare SQL statement to delete user by ID
		$sql = "DELETE FROM tbl_user WHERE user_id = :user_id";
		$stmt = $this->conn->prepare($sql);
		
		// Bind parameter
		$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
		
		// Execute the query
		$stmt->execute();
		
		// Check if any rows were affected (i.e., if the deletion was successful)
		if ($stmt->rowCount() > 0) {
			return true; // Deletion successful
		} else {
			return false; // Deletion failed
		}
	}
	
}
?>
