<?php

class EventVolunteer{
    // Database connection details
    private $DB_SERVER = '172.16.0.214';
    private $DB_USERNAME = 'group46';
    private $DB_PASSWORD = '123456';
    private $DB_DATABASE = 'group46';
    private $conn;

    // Constructor to establish database connection
    public function __construct(){
        $this->conn = new PDO("mysql:host=".$this->DB_SERVER.";dbname=".$this->DB_DATABASE,$this->DB_USERNAME,$this->DB_PASSWORD);
    }
    
    // Method to apply for an event
    public function new_event_application($vp_id, $e_id) {
        // Check if the maximum number of applicants has been reached
        if ($this->is_max_applicants_reached($e_id)) {
            return false; // Maximum number of applicants reached
        }
    
        // Proceed with the application process
        // Prepare the SQL statement for inserting a new event application
        $stmt = $this->conn->prepare("INSERT INTO tbl_event_applications (vp_id, e_id) VALUES (?, ?)");
    
        try {
            // Begin transaction
            $this->conn->beginTransaction();
    
            // Execute the SQL statement
            $stmt->execute([$vp_id, $e_id]);
    
            // Commit transaction
            $this->conn->commit();
    
            return true; // Return true on success
        } catch (Exception $e) {
            // Rollback transaction on failure
            $this->conn->rollback();
    
            // Log error message
            error_log("Error creating new event application: " . $e->getMessage());
    
            return false; // Return false on failure
        }
    }
    
    // Method to check if the maximum number of applicants for an event has been reached
    public function is_max_applicants_reached($e_id) {
        $max_applicants = 3; 
        
        // Get the current number of applicants for the event
        $current_applicants = $this->get_num_applicants($e_id);
    
        // Check if the current number of applicants equals or exceeds the maximum
        return $current_applicants >= $max_applicants;
    }
    
    

    // Method to check if a volunteer has already applied for an event
    public function is_applied($vp_id, $e_id) {
        $sql = "SELECT COUNT(*) AS count FROM tbl_event_applications WHERE vp_id = ? AND e_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$vp_id, $e_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] > 0;
    }

    // Method to retrieve the number of applicants for an event
    public function get_num_applicants($e_id) {
        $sql = "SELECT COUNT(*) AS num_applicants FROM tbl_event_applications WHERE e_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$e_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['num_applicants'];
    }
}



?>