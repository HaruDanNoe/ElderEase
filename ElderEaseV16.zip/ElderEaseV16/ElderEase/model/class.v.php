<?php
class Volunteer{
    // Database connection details
    private $DB_SERVER = '172.16.0.214';
    private $DB_USERNAME = 'group46';
    private $DB_PASSWORD = '123456';
    private $DB_DATABASE = 'group46';
    private $conn;
    // Constructor to establish database connection
    public function __construct(){
        $this->conn = new PDO("mysql:host=".$this->DB_SERVER.";dbname=".$this->DB_DATABASE,$this->DB_USERNAME,$this->DB_PASSWORD);
    }
    
    // Method to add a new volunteer
    public function new_volunteer($vp_name, $vp_phonenumber, $vp_email, $vp_password, $vp_status, $vpbiodata) {
        // Get the current date and time
        $NOW = new DateTime('now', new DateTimeZone('Asia/Manila'));
        $NOW = $NOW->format('Y-m-d H:i:s');
        
        // Prepare SQL statement to insert new volunteer into the database
        $stmt = $this->conn->prepare("INSERT INTO tbl_volunteerapplication (vp_name, vp_phonenumber, vp_email, vp_password, vp_status, vp_biodata) VALUES (?, ?, ?, ?, ?, ?)");
        
        try {
            // Begin transaction
            $this->conn->beginTransaction();
            
            // Execute the SQL statement
            $stmt->execute([$vp_name, $vp_phonenumber, $vp_email, $vp_password, $vp_status, $vpbiodata]);
            
            // Commit transaction
            $this->conn->commit();
            
            return true; // Return true on success
        } catch (Exception $e) {
            // Rollback transaction on failure
            $this->conn->rollback();
            
            // Log error message
            error_log("Error creating new volunteer: " . $e->getMessage());
            
            return false; // Return false on failure
        }
    }
    
    
    // Method to update volunteer information
    public function update_volunteer($vp_name, $vp_phonenumber, $vp_email, $vp_password, $vp_status, $vp_id) {
        // Get the current date and time
        $now = date('Y-m-d H:i:s');
        
        // Prepare SQL statement to update volunteer information
        $stmt = $this->conn->prepare("UPDATE tbl_volunteerapplication SET vp_name=?, vp_phonenumber=?, vp_email=?, vp_password=?, vp_status=?, updated_at=? WHERE vp_id=?");
        
        try {
            // Begin transaction
            $this->conn->beginTransaction();
            
            // Execute the SQL statement
            $stmt->execute([$vp_name, $vp_phonenumber, $vp_email, $vp_password, $vp_status, $now, $vp_id]);
            
            // Commit transaction
            $this->conn->commit();
            
            return true; // Return true on success
        } catch (Exception $e) {
            // Rollback transaction on failure
            $this->conn->rollback();
            
            // Log error message
            error_log("Error updating volunteer: " . $e->getMessage());
            
            return false; // Return false on failure
        }
    }
    
    // Method to deactivate a volunteer
    public function deactivate_volunteer($vp_id) {
        // Get the current date and time
        $now = date('Y-m-d H:i:s');
        
        // Prepare SQL statement to deactivate volunteer
        $stmt = $this->conn->prepare("UPDATE tbl_volunteerapplication SET vp_status=?, updated_at=? WHERE vp_id=?");
        
        try {
            // Begin transaction
            $this->conn->beginTransaction();
            
            // Execute the SQL statement
            $stmt->execute([0, $now, $vp_id]);
            
            // Commit transaction
            $this->conn->commit();
            
            return true; // Return true on success
        } catch (Exception $e) {
            // Rollback transaction on failure
            $this->conn->rollback();
            
            // Log error message
            error_log("Error deactivating volunteer: " . $e->getMessage());
            
            return false; // Return false on failure
        }
    }
    
    // Method to delete a volunteer
    public function delete_volunteer($vp_id) {
        // Prepare SQL statement to delete volunteer
        $stmt = $this->conn->prepare("DELETE FROM tbl_volunteerapplication WHERE vp_id=?");
        
        try {
            // Begin transaction
            $this->conn->beginTransaction();
            
            // Execute the SQL statement
            $stmt->execute([$vp_id]);
            
            // Commit transaction
            $this->conn->commit();
            
            return true; // Return true on success
        } catch (Exception $e) {
            // Rollback transaction on failure
            $this->conn->rollback();
            
            // Log error message
            error_log("Error deleting volunteer: " . $e->getMessage());
            
            return false; // Return false on failure
        }
    }
    
    // Method to retrieve a list of all volunteers
    public function list_volunteers(){
        $sql = "SELECT * FROM tbl_volunteerapplication";
        $q = $this->conn->query($sql) or die("Failed to fetch volunteers!");
        while($r = $q->fetch(PDO::FETCH_ASSOC)){
            $data[] = $r;
        }
        if(empty($data)){
            return false;
        } else {
            return $data;
        }
    }

    function update_volunteer_status($vp_id, $vp_status) {
        // Prepare and execute the SQL statement to update the status of the volunteer
        $sql = "UPDATE tbl_volunteerapplication SET vp_status = :vp_status WHERE vp_id = :vp_id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':vp_id', $vp_id, PDO::PARAM_INT);
        $stmt->bindParam(':vp_status', $vp_status, PDO::PARAM_INT);
        $stmt->execute();
    
        // Check if any rows were affected (i.e., if the update was successful)
        if ($stmt->rowCount() > 0) {
            return true; // Update successful
        } else {
            return false; // Update failed
        }
    }

    public function get_volunteer($vp_id) {
        $stmt = $this->conn->prepare("SELECT * FROM tbl_volunteerapplication WHERE vp_id = ?");
        $stmt->execute([$vp_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>
