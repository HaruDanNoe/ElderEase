<?php

session_start(); // Start the session

include '../model/class.event.php';
include '../model/class.v.php';
include '../model/class.e.v.php'; // Include the EventApplication class

$events = new Event();
$volunteer = new Volunteer();


$vp_id = $_GET['vp_id'] ?? ''; // Check if vp_id is set

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events to Apply</title>
    <link rel="icon" type="image/x-icon" href="../img/icon/favicon.ico">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .welcome-div {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .topic-text {
            text-align: center;
            margin-bottom: 20px;
        }
        .card-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            grid-gap: 20px;
        }
        .card {
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 15px;
        }
        .card-header {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
            height: 50px;
        }
        .card-body {
            font-size: 16px;
            line-height: 1.5;
        }
        button {
            padding: 8px 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<div class="welcome-div">
    <div class="topic-text">
        <h1>Events to Apply</h1>
        <p>Events and Schedule</p>
    </div>

    <div class="card-container">
        <?php
        $count = 1;
        if ($events->list_events() != false) {
            foreach ($events->list_events() as $value) {
                extract($value);

                // Get the number of volunteers applied for this event
                $event_volunteer = new EventVolunteer();
                $num_applicants = $event_volunteer->get_num_applicants($e_id);

                ?>
                <form action="../controller/peventvolunteer.php?action=apply" method="POST">

                    <input type="hidden" name="vp_id"   value="<?php echo $vp_id; ?>">
                    <input type="hidden" name="e_id"    value="<?php echo $e_id; ?>">

                    <div class="card">
                        <div class="card-header"><?php echo $e_description; ?></div>
                        <div class="card-body">
                            <p>
                                Date:               <?php echo $e_date; ?><br>
                                Start Time:         <?php echo $e_stime; ?><br>
                                End Time:           <?php echo $e_etime; ?><br>
                                Volunteers Applied: <?php echo $num_applicants; ?><br>
                                
                                <?php
                                // Check if the maximum number of applicants is reached
                                $event_volunteer = new EventVolunteer();
                                if ($event_volunteer->is_max_applicants_reached($e_id)) {
                                    echo "<span style='color:red;'>Maximum number of applicants reached for this event.</span>";
                                } else {
                                    echo "<button type='submit'>Apply</button>";
                                }
                                ?>
                            </p>
                        </div>
                    </div>

                </form>
                <?php
                $count++;

            }
        } else {
            echo "No Record Found.";
        }
        ?>
    </div>
</div>
</body>
</html>
