<?php
include_once '../model/class.elder.php';
$elder = new Elder();


        $data = $elder->get_elder($_GET['id']);
        $p_id = $_GET['id'] ?? '';   
        //var_dump($data);

?>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Update</title>
    <link rel="icon" type="image/x-icon" href="../img/icon/favicon.ico">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Madimi+One&family=Sue+Ellen+Francisco&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300&family=Krona+One&family=Montserrat:wght@100;200;300;600&display=swap">

    <style>
        body {
            font-family: 'Montserrat', sans-serif; /* Use the Montserrat font as the default font */
            margin: 0;
            padding: 0;
            background-image: url('../img/bg/aboutbg.png');
            background-position-x: initial;
            background-position-y: initial;
            background-size: cover;
            background-attachment: initial;
            background-origin: initial;
            background-clip: initial;
            background-color: initial;
            background-repeat-x: no-repeat;
            background-repeat-y: no-repeat;
        }
        #form-container {
            width: 50%;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset;            margin-bottom: 20px;
        }
        .input-group {
            margin-bottom: 15px;
        }
        .input-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .input-group input {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        #button-block {
            text-align: center;
            
        }
        #button-block input[type="submit"] {
            padding: 10px 20px;
            background: -webkit-linear-gradient(#137fd2, #1e9eff);
            border: none;
            box-shadow: rgba(0, 0, 0, 0.19) 0px 10px 20px, rgba(0, 0, 0, 0.23) 0px 6px 6px;            color: #fff;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        #button-block input[type="submit"]:hover {
            background-color: #45a049;
        }
        h3{
            font-size: 40px;
            font-family: "Madimi One", sans-serif;
            font-weight: 400;
            font-style: normal;
            background: -webkit-linear-gradient(#137fd2, #1e9eff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>


<div id="form-container">
<h3>Provide the Required Information</h3>

    <form method="POST" action="../controller/pelder.php?action=update">
      
        <div class="input-group">
            <label for="fullname">Full Name</label>
            <input type="text" id="fullname" class="input" name="p_fullname" value="<?php echo $data['p_fullname'] ?? ''; ?>" placeholder="Full Name" required>
    </div>

    <div class="input-group">
            <label for="gender">Gender</label>
            <input type="text" id="gender" class="input" name="p_gender" value="<?php echo $data['p_gender'] ?? ''; ?>" placeholder="Gender" required>
    </div>


            <!-- 
            <label for="address">Address</label>
            <input type="text" id="address" class="input" name="p_address" value="<?php echo $data['p_address'] ?? ''; ?>" placeholder="Address"> -->
       
            <div class="input-group">
                <label for="age">Age</label>
                <input type="number" id="age" class="input" name="p_age" value="<?php echo $data['p_age'] ?? ''; ?>" placeholder="Age" required>
    </div>

    <div class="input-group">
            <label for="birthday">Birthday</label>
            <input type="date" id="birthday" class="input" name="p_birthday" value="<?php echo $data['p_birthday'] ?? ''; ?>" placeholder="Birthday" required>
    </div>

    <div class="input-group">
            <label for="status">Status</label>
            <input type="text" id="status" class="input" name="p_status" value="<?php echo $data['p_status'] ?? ''; ?>" placeholder="Status" required>
    </div>
      
    <div class="input-group">
            <label for="medicalhistory">Medical History</label>
            <input type="text" id="medicalhistory" class="input" name="p_medicalhistory" value="<?php echo $data['p_medicalhistory'] ?? ''; ?>" placeholder="Medical History" required>
    </div>

    
        <div id="button-block">
            <input type="hidden" name="p_id" value="<?php echo $p_id; ?>">
            <input type="submit" value="Update">
        </div>
    </form>
</div>
