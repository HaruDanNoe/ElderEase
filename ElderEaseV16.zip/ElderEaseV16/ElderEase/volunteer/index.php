<?php
session_start(); // Start the session

include_once '../model/class.elder.php';
include_once '../model/class.v.php'; // Include the Volunteer class if needed
// Include any other necessary model or class files here

$elder = new Elder();
$volunteer = new Volunteer();

$p_id = $_GET['p_id'] ?? '';
$page = $_GET['page'] ?? ''; // Define the $page variable

// $data = $volunteer->get_volunteer($_GET['vp_id']);
// $vp_id = $_GET['vp_id'] ?? '';

?>
<head>
<title>Volunteer Dashboard</title>
    <link rel="icon" type="image/x-icon" href="../img/icon/favicon.ico">
    <link href="../css/style.css" rel="stylesheet" type="text/css"<?php echo time();?>>

</head>

<header class="header">
<nav class="navi">
    
<h1 class="navi-logo">Volunteer</h1><br>
  
<ul class="navi_items">
    <li class="navi_item">
    <a href="create-elder.php?action=create" class="navi_link">New Elder</a> <br>
    <a href="event.php?vp_id=<?php echo $vp_id; ?>" class="navi_link">Events to Apply</a> <br>
    
    <div class="navv">
    <a href="../logout.php" class="button">Log Out</a> 

    </div>
    </li>
</ul>
   </nav>
</header>


<div class="welcome-div-admin">
<div id="subcontent">

<h1>Elders</h1>
<table id="data-list">
    <tr>
        <th>#</th>
        <th>Full Name</th>
        <th>Gender</th>
        <th>Age</th>
        <th>Birthday</th>
        <th>Status</th>
        <th>Medical History</th>
        <th>Action</th>

    </tr>
    <?php
    $count = 1;
    if ($elder->list_elders() != false) {
        foreach ($elder->list_elders() as $value) {
            extract($value);
    ?>
            <tr>
                <td><?php echo $count; ?></td>
                <td><?php echo $p_fullname; ?></td>
                <td><?php echo $p_gender; ?></td>
                <td><?php echo $p_age; ?></td>
                <td><?php echo $p_birthday; ?></td>
                <td><?php echo $p_status; ?></td>
                <td><?php echo $p_medicalhistory; ?></td>
                <td><button onclick="return confirm('Are you sure?')"><a href="delete.php?action=delete&id=<?php echo $p_id; ?>">Delete</a></button>
                <a href="update.php?action=update&id=<?php echo $p_id; ?>">Update</a>
                 </td>
            </tr>
    <?php
            $count++;
        }
    } else {
        echo "No Record Found.";
    }
    ?>
</table>
</div>

</div>
<!-- <?php var_dump($vp_id);?> -->
