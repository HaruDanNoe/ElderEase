<?php
include '../model/class.event.php';

// Check if user ID is provided and if it's a valid integer
if(isset($_GET['id']) && is_numeric($_GET['id'])){
    $e_id = $_GET['id'];
    
    // Create an instance of the event class
    $events = new Event();
    
    $deleted = $events->delete_event($e_id);
    
    if($deleted){
        // If deletion is successful, redirect back to the user list page
        header('Location: event.php');
        exit();
    } else {
        // If deletion fails, display an error message
        echo "Failed to delete user.";
    }
} else {
    // If user ID is not provided or not valid, display an error message
    echo "Invalid user ID.";
}
?>
