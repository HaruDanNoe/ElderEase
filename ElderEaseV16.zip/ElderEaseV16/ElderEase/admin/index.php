

<?php
include '../model/class.user.php';
include_once '../model/class.v.php';

$user = new User();
$volunteer = new Volunteer();


?>
<head>
    <title>Admin Dashboard</title>
    <link rel="icon" type="image/x-icon" href="../img/icon/favicon.ico">
    <link href="../css/style.css" rel="stylesheet" type="text/css"<?php echo time();?>>

   
    
</head>

<body>


<header class="header">
<nav class="navi">
    
<h1 class="navi-logo">ADMIN</h1><br>
  
<ul class="navi_items">
    <li class="navi_item">
    <a href="create-user.php?action=create" class="navi_link">New User</a>
    <a href="event.php" class="navi_link">Events</a> 
    
    <div class="navv">
    <a href="../logout.php" class="button">Log Out</a> 

    </div>
    </li>
</ul>
   </nav>
</header>


<div class="welcome-div-admin">
<div id="subcontent">


<h1>Users</h1>
<table id="data-list">
    <tr>
        <th>#</th>
        <th>User ID</th>
        <th>Name</th>
        <th>Gender</th>
        <th>Age</th>
        <th>Address</th>
        <th>Phone Number</th>
        <th>Role</th>
        <th>Email</th>
        <th>Date & Time Added</th>
        <th>Actions</th>
    </tr>
    <?php
    $count = 1;
    if ($user->list_users() != false) {
        foreach ($user->list_users() as $value) {
            extract($value);
    ?>
            <tr>
                <td><?php echo $count;?></td>
                <td><?php echo $user_id ?></td>
                <td><?php echo $user_lname.', '.$user_fname;?></td>
                <td><?php echo $user_gender ?></td>
                <td><?php echo $user_age ?> years old</td>
                <td><?php echo $user_address ?></td>
                <td><?php echo $user_phonenumber ?></td>
                <td><?php echo $user_role;?></td>
                <td><?php echo $user_email;?></td>
                <td><?php echo $user_date_added. ', '.$user_time_added;?></td>
                <td>
                    <button onclick="return confirm('Are you sure?')"><a href="delete.php?action=delete&user_id=<?php echo $user_id;?>">Delete</a></button>
                    <a href="update.php?action=update&user_id=<?php echo $user_id;?>">Update</a>
                </td>
            </tr>
    <?php
            $count++;
        }
    } else {
        echo "No Record Found.";
    }
    ?>
</table>
<br>
<h1>New Volunteer Applications</h1>
<table id="data-list">
    <tr>
        <th>#</th>
        <th>ID</th>
        <th>Fullname</th>
        <th>Phone Number</th>
        <th>Email</th>
        <th>Biodata</th>
        <th>Status</th>
        <th>Actions</th>
    </tr>
    <?php
    $count = 1;
    if ($volunteer->list_volunteers() != false) {
        foreach ($volunteer->list_volunteers() as $value) {
            extract($value);
    ?>
            <tr>
                <td><?php echo $count; ?></td>
                <td><?php echo $vp_id; ?></td>
                <td><?php echo $vp_name; ?></td>
                <td><?php echo $vp_phonenumber; ?></td> 
                <td><?php echo $vp_email; ?></td>
                <td>
                    <?php 
                    // Display a download link for the file
                    echo "<a href='$vp_biodata' target='_blank'>Download</a>";
                    ?>
                </td>
                <td><?php echo $vp_status; ?></td>
                <td>
                    <button onclick="return confirm('Are you sure?')"><a href="accept.php?action=accept&id=<?php echo $vp_id; ?>">Accept</a></button>
                    <a href="accept.php?action=reject&id=<?php echo $vp_id; ?>">Decline</a>
                </td>
            </tr>

    <?php
            $count++;
        }
    } else {
        echo "No Record Found.";
    }
    ?>
</table>

</div>
</div>
   



</body>