<?php
include_once '../model/class.v.php';

$volunteer = new Volunteer();

$vp_id = $_GET['id'] ?? '';
$action = $_GET['action'] ?? '';

if (!empty($vp_id) && !empty($action)) {
    switch ($action) {
        case 'accept':
            $status = 1; // Set status to 1 for accepted
            $message = "Volunteer accepted successfully.";
            break;
        case 'reject':
            $status = 0; // Set status to 0 for rejected
            $message = "Volunteer rejected successfully.";
            break;
        default:
            $message = "Invalid action.";
            break;
    }

    // Update volunteer status in the database
    if ($volunteer->update_volunteer_status($vp_id, $status)) {
        // JavaScript to display the message as an alert and redirect back
        echo "<script>alert('$message'); window.location.href = 'index.php';</script>";
    } else {
        // JavaScript to display the failure message as an alert and redirect back
        echo "<script>alert('Failed to update volunteer status.'); window.location.href = 'index.php';</script>";
    }
} else {
    // JavaScript to display the invalid action message as an alert and redirect back
    echo "<script>alert('Invalid volunteer ID or action.'); window.location.href = 'index.php';</script>";
}
?>
