<?php
include '../model/class.user.php';

// Check if user ID is provided and if it's a valid integer
if(isset($_GET['user_id']) && is_numeric($_GET['user_id'])){
    $user_id = $_GET['user_id'];
    
    // Create an instance of the User class
    $user = new User();
    
    $deleted = $user->delete_user($user_id);
    
    if($deleted){
        // If deletion is successful, redirect back to the user list page
        header('Location: index.php');
        exit();
    } else {
        // If deletion fails, display an error message
        echo "Failed to delete user.";
    }
} else {
    // If user ID is not provided or not valid, display an error message
    echo "Invalid user ID.";
}
?>
