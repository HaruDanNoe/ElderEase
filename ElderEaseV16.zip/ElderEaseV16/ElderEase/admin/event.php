<?php 
include '../model/class.event.php';
include '../model/class.v.php';
include '../model/class.e.v.php'; // Include the EventApplication class

$events = new Event();
$volunteer  = new Volunteer();

?>

<head>
<title>Admin Dashboard</title>
    <link rel="icon" type="image/x-icon" href="../img/icon/favicon.ico">
    <link href="../css/style.css" rel="stylesheet" type="text/css"<?php echo time();?>>

</head>
  
<body>

<header class="header">
<nav class="navi">
    
<h1 class="navi-logo">ADMIN</h1><br>
  
<ul class="navi_items">
    <li class="navi_item">
    <a href="index.php" class="navi_link">User</a>
    <a href="event.php" class="navi_link">Events</a> 
    
    <div class="navv">
    <a href="../logout.php" class="button">Log Out</a> 

    </div>
    </li>
</ul>
   </nav>
</header>


<div class="welcome-div-admin">
<div id="subcontent">

<h1>Event and Schedule</h1>
    <table id="data-list">
      <tr>
        <th>Date              </th>
        <th>Start Time        </th>
        <th>End Time          </th>
        <th>Event             </th>
        <th>Volunteers Applied</th>
        <th>Action            </th>
      </tr>
 
 
 <?php
  $count = 1;
  if($events->list_events() != false)
  {
    foreach($events->list_events() as $value)
    {
        extract($value);
          $event_volunteer = new EventVolunteer();
          $num_applicants = $event_volunteer->get_num_applicants($e_id);
        ?>

        <tr>
            <td><?php echo $e_date;         ?></td>
            <td><?php echo $e_stime;        ?></td>
            <td><?php echo $e_etime;        ?></td>
            <th><?php echo $e_description;  ?></th>
            <th><?php echo $num_applicants; ?></th>
          <td><button onclick="return confirm('Are you sure?')"><a href="deletee.php?action=delete&id=<?php echo $e_id;?>">Delete</a></button></td>
        </tr>
        <?php
        $count++;
    }
  }
  else
  {
     echo "No Record Found.";
  }
  // var_dump($_GET);

  $error = $_GET['error'] ?? false;
  
  if($error == 'duplicate')
  {
    echo '<p style="color:red;">The event you added has a conflict to another event\'s time. Please choose another time.</p>';

  }
  
  ?>
    </table>

<br>


<div id="form-block-event">

    <form method="POST" action="../controller/pevent.php?action=new">

        <h2>Add Event</h2>

        
            <label for="date">Date:</label>
            <input type="date" id="date" class="input-event" name="e_date" placeholder="Date" required> <br>

            <label for="date">Start Time:</label>
            <input type="time" id="date" class="input-event" name="e_stime" placeholder="Start Time" required> <br>

            <label for="date">End Time:</label>
            <input type="time" id="date" class="input-event" name="e_etime" placeholder="End Time" required> <br>

            <label for="des">Event:</label>
            <input type="text" id="des" class="input-event" name="e_description" placeholder="Event" required>
<br>
            <input type="submit" value="Save">


</form>
</div>
</div>

</body>