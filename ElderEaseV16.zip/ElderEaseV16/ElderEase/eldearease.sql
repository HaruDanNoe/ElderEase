-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2024 at 03:38 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eldearease`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_donation`
--

CREATE TABLE `tbl_donation` (
  `d_id` int(11) NOT NULL,
  `d_name` varchar(100) DEFAULT NULL,
  `d_email` varchar(100) DEFAULT NULL,
  `d_phonenumber` varchar(20) DEFAULT NULL,
  `d_comment` text DEFAULT NULL,
  `d_amount` decimal(10,2) DEFAULT NULL,
  `d_pmethod` blob DEFAULT NULL,
  `d_datetransaction` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_donation`
--

INSERT INTO `tbl_donation` (`d_id`, `d_name`, `d_email`, `d_phonenumber`, `d_comment`, `d_amount`, `d_pmethod`, `d_datetransaction`) VALUES
(1, 'Nagedd', 'adad@gmail.com', '0989859595', 'ajdjadajdad', 656556.00, 0x2e2e2f766965772f646f6e6174652f726563656970742f5245464c4543544956454a4f55524e414c2320312e706466, '2024-03-08'),
(3, 'Nagedd', 'aadadd@gmail.com', '0989859595666646', 'adadnadmada', 65000.00, 0x2e2e2f766965772f646f6e6174652f726563656970742f322e332e332041737369676e6d656e7420315f20444220616e64205461626c65732e706466, '2024-03-08'),
(9, 'Nagedd', 'aadadd@gmail.com', '09566464', 'adadnadmada', 65000.00, 0x2e2e2f766965772f646f6e6174652f726563656970742f322e332e332041737369676e6d656e7420315f20444220616e64205461626c65735f47726f757023312e706466, '2024-03-08');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_event`
--

CREATE TABLE `tbl_event` (
  `e_id` int(11) NOT NULL,
  `e_date` date DEFAULT NULL,
  `e_stime` time DEFAULT NULL,
  `e_etime` time DEFAULT NULL,
  `e_description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_event`
--

INSERT INTO `tbl_event` (`e_id`, `e_date`, `e_stime`, `e_etime`, `e_description`) VALUES
(24, '4454-04-05', '18:55:00', '18:06:00', 'akjnkdknakd');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_event_applications`
--

CREATE TABLE `tbl_event_applications` (
  `application_id` int(11) NOT NULL,
  `e_id` int(11) DEFAULT NULL,
  `vp_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_event_applications`
--

INSERT INTO `tbl_event_applications` (`application_id`, `e_id`, `vp_id`) VALUES
(17, 24, 14);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_patients`
--

CREATE TABLE `tbl_patients` (
  `p_id` int(11) NOT NULL,
  `p_fullname` varchar(100) DEFAULT NULL,
  `p_gender` varchar(10) DEFAULT NULL,
  `p_age` int(11) DEFAULT NULL,
  `p_birthday` date DEFAULT NULL,
  `p_status` varchar(50) DEFAULT NULL,
  `p_medicalhistory` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `user_fname` varchar(50) DEFAULT NULL,
  `user_lname` varchar(50) DEFAULT NULL,
  `user_gender` varchar(10) DEFAULT NULL,
  `user_age` int(11) DEFAULT NULL,
  `user_address` varchar(255) DEFAULT NULL,
  `user_phonenumber` varchar(20) DEFAULT NULL,
  `user_role` varchar(20) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `user_password` varchar(100) DEFAULT NULL,
  `user_confirmpassword` varchar(100) DEFAULT NULL,
  `user_date_added` date NOT NULL DEFAULT current_timestamp(),
  `user_time_added` time NOT NULL DEFAULT current_timestamp(),
  `user_status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_fname`, `user_lname`, `user_gender`, `user_age`, `user_address`, `user_phonenumber`, `user_role`, `user_email`, `user_password`, `user_confirmpassword`, `user_date_added`, `user_time_added`, `user_status`) VALUES
(6, 'ANlie', 'Wwf', 'female', 19, 'murcia', '0656262', 'Admin', 'E@gmail.com', '123', '123', '2024-03-08', '21:00:57', '1'),
(7, 'ronn', 'reddick', 'male', 15, 'cebu', '09894545646', 'Finance', 'f@gmail.com', '123', '123', '2024-03-08', '00:00:00', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_volunteerapplication`
--

CREATE TABLE `tbl_volunteerapplication` (
  `vp_id` int(11) NOT NULL,
  `vp_name` varchar(100) DEFAULT NULL,
  `vp_email` varchar(100) DEFAULT NULL,
  `vp_password` varchar(15) DEFAULT NULL,
  `vp_phonenumber` varchar(11) DEFAULT NULL,
  `vp_biodata` blob DEFAULT NULL,
  `vp_status` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_volunteerapplication`
--

INSERT INTO `tbl_volunteerapplication` (`vp_id`, `vp_name`, `vp_email`, `vp_password`, `vp_phonenumber`, `vp_biodata`, `vp_status`) VALUES
(14, 'Akdwndnkdnd', 'ada@gmail.com', '123', '266466', 0x2e2e2f766965772f766f6c756e746565722f767062696f646174612f4d6f72652066616d696c7920707570706574732e706466, 1),
(27, 'Asas', 'q@gmail.com', '554555', '094494', 0x2e2e2f766965772f766f6c756e746565722f767062696f646174612f72526573756d65315f416e67656c204d616520456e646f6d612e706466, 0),
(29, 'As', 'aw@gmail.com', 'create12', '09989898989', 0x2e2e2f766965772f766f6c756e746565722f767062696f646174612f43433130345f2d41737369676e6d656e742d312d322e706466, 0),
(30, 'As', 'qas@gmail.com', 'create23', '094494', 0x2e2e2f766965772f766f6c756e746565722f767062696f646174612f496e746f6e672e646f6378, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_donation`
--
ALTER TABLE `tbl_donation`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `tbl_event`
--
ALTER TABLE `tbl_event`
  ADD PRIMARY KEY (`e_id`),
  ADD UNIQUE KEY `e_stime` (`e_stime`),
  ADD UNIQUE KEY `unique_description_constraint` (`e_description`) USING HASH;

--
-- Indexes for table `tbl_event_applications`
--
ALTER TABLE `tbl_event_applications`
  ADD PRIMARY KEY (`application_id`),
  ADD UNIQUE KEY `vp_id` (`vp_id`),
  ADD KEY `tbl_event_applications_ibfk_1` (`e_id`);

--
-- Indexes for table `tbl_patients`
--
ALTER TABLE `tbl_patients`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_email` (`user_email`),
  ADD UNIQUE KEY `user_phonenumber` (`user_phonenumber`);

--
-- Indexes for table `tbl_volunteerapplication`
--
ALTER TABLE `tbl_volunteerapplication`
  ADD PRIMARY KEY (`vp_id`),
  ADD UNIQUE KEY `unique_password` (`vp_password`),
  ADD UNIQUE KEY `vp_email` (`vp_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_donation`
--
ALTER TABLE `tbl_donation`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_event`
--
ALTER TABLE `tbl_event`
  MODIFY `e_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_event_applications`
--
ALTER TABLE `tbl_event_applications`
  MODIFY `application_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_patients`
--
ALTER TABLE `tbl_patients`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_volunteerapplication`
--
ALTER TABLE `tbl_volunteerapplication`
  MODIFY `vp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_event_applications`
--
ALTER TABLE `tbl_event_applications`
  ADD CONSTRAINT `tbl_event_applications_ibfk_1` FOREIGN KEY (`e_id`) REFERENCES `tbl_event` (`e_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tbl_event_applications_ibfk_2` FOREIGN KEY (`vp_id`) REFERENCES `tbl_volunteerapplication` (`vp_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
