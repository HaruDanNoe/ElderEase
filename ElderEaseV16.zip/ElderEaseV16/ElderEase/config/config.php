<?php
date_default_timezone_set("Asia/Manila");
	session_start();
	define('DB_SERVER','172.16.0.214');
	define('DB_USERNAME','group46');
	define('DB_PASSWORD','12345');
	define('DB_DATABASE','group46');
?>