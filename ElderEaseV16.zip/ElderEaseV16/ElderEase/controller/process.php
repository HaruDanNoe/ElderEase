<?php
// Include the User class file
include '../model/class.user.php';

// var_dump($_GET);
// exit();
// Check if 'action' parameter is set in the URL, if not, set it to an empty string
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Switch statement based on the value of 'action'
switch($action){
    // If action is 'new', call the function create_new_user()
    case 'new':
        create_new_user();
    break;
    case 'update':
        update_user();
    break;
    // If action is 'deactivate', call the function deactivate_user()
    case 'deactivate':
        deactivate_user();
        break;
    case 'delete':
        delete_user();
    break;
}

session_start();

if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    // Redirect the user to their account page
    $user_id = $_SESSION['user_id'];
    $user_role = $_SESSION['user_role'];

    switch ($user_role) {
        case 'Admin':
            header('Location: admin/index.php?user_id=' . $user_id);
            break;
        case 'Volunteer':
            header('Location: volunteer/index.php?user_id=' . $user_id);
            break;
        case 'Finance':
            header('Location: finance/index.php?user_id=' . $user_id);
            break;
        default:
            header('Location: ../index.php?user_id=' . $user_id);
            header("wrong email");
            break;
    }

    exit();
}


// Function to create a new user
function create_new_user() {
    $user = new User();
    
    // Check if the form data is set
    if(isset($_POST['user_fname'], $_POST['user_lname'], $_POST['user_gender'], $_POST['user_age'],
             $_POST['user_address'], $_POST['user_phonenumber'], $_POST['user_role'], $_POST['user_email'],
             $_POST['user_password'], $_POST['user_confirmpassword'])) {
        
        // Extract and sanitize form data
        $user_fname             = ucwords($_POST['user_fname']);
        $user_lname             = ucwords($_POST['user_lname']);
        $user_gender            = $_POST['user_gender'];
        $user_age               = $_POST['user_age']; // Assuming age doesn't need to be capitalized
        $user_address           = ucwords($_POST['user_address']);
        $user_phonenumber       = ucwords($_POST['user_phonenumber']);
        $user_role              = ucwords($_POST['user_role']);
        $user_email             = strtolower($_POST['user_email']); // Convert email to lowercase
        $user_password          = $_POST['user_password'];
        $user_confirmpassword   = $_POST['user_confirmpassword'];
        
        
        // Validate form data here if necessary
        
        // Hash the password
        $hashed_password        = password_hash($user_password, PASSWORD_DEFAULT);
        $hashed_confirmpassword = password_hash($hashed_confirmpassword, PASSWORD_DEFAULT);
        
        // Call the new_user method of the User class to create a new user
        $result = $user->new_user(  $user_fname, $user_lname, $user_gender, $user_age, $user_address, 
                                    $user_phonenumber, $user_role, $user_email, $hashed_password, $hashed_confirmpassword);
        
        if($result) {
            // Get the user id
            $user_id = $user->get_user_id($user_email);
            // Redirect to profile page
            header('location: ../admin/index.php?action=profile&id='.$user_id);
            exit(); // Exit to prevent further execution
        } else {
            // Handle errors if necessary
            // For example, display an error message to the user
            echo "Error creating user.";
        }
    } else {
        // Handle case where form data is not set
        // For example, display an error message to the user
        echo "Form data is missing.";
    }
}


// Function to update user information,
function getUserDetails($user_id){
    // Create a new instance of the User class
    $user = new User();
     
    // Call the update_user method of the User class to update user information
    $result = $user->get_user($user_id);
    
    // If user update is successful, redirect to user profile page
    if($result){
        // Redirect to the user profile page with the user ID in the URL
        header('location: ../admin/update.php?page=settings&subpage=users&action=profile&id='.$user_id);
    }
}

function update_user() {
    // Check if user ID is provided in the POST data
    if (!isset($_POST['user_id'])) {

        //var_dump($user_id);
        // If user ID is not provided, redirect back to the admin page
        header('location: ../admin/index.php');
        exit(); // Stop further execution
    }

    // Create a new instance of the User class
    $user = new User();

    // Extract form data and sanitize/validate if necessary
    $user_id            = $_POST['user_id'];
    $user_fname         = ucwords(trim($_POST['user_fname'])); // Trim and capitalize first letter of each word
    $user_lname         = ucwords(trim($_POST['user_lname'])); // Trim and capitalize first letter of each word
    $user_phonenumber   = $_POST['user_phonenumber']; // Validate phone number format if needed
    $user_role          = ucwords(trim($_POST['user_role'])); // Trim and capitalize first letter of each word
    $user_email         = $_POST['user_email']; // Validate email format if needed
    var_dump($user);
    // Call the update_user method of the User class to update user information
    try {
        $result = $user->update_user($user_fname, $user_lname, $user_phonenumber, $user_role, $user_email, $user_id);
        
        // If user update is successful, redirect to user profile page
        if ($result) {
            // Redirect to the user profile page with the user ID in the URL
            header('location: ../admin/index.php?action=profile&id='.$user_id);
            exit(); // Stop further execution after redirect
        } else {

                       // Handle update failure here, if needed
            // For example, display an error message
            echo "Failed to update user. Please try again.";
        }
    } catch (PDOException $e) {
        // Log the error for debugging purposes
        error_log("Database error: " . $e->getMessage());

        // Display a user-friendly error message
        echo "Failed to update user. Please try again later.";
    }
}



function deactivate_user() {
    // Create a new instance of the User class
    $user = new User();
    
    // Extract form data
    $user_id = $_POST['user_id']; 
    
    // Call the deactivate_user method of the User class to deactivate the userid
    $result = $user->deactivate_user($user_id);
    
    // If user deactivation is successful, redirect to user profile page
    if ($result) {
        // Redirect to the user profile page with the user ID in the URL
        header('location: ../index.php?page=settings&subpage=users&action=profile&id='.$user_id);
    }
}

function delete_user() {
    $user       = new User();
    $user_id    = isset($_GET['id']) ? $_GET['id'] : '';

    // Check if user ID is provided
    if (!empty($user_id)) {
        // Perform deletion
        $result = $user->delete_user($user_id);

        // Redirect back to the page where the user was deleted from
        header('location: ../index.php?page=settings&subpage=users');
    } else {
        // Redirect to a relevant error page if no user ID is provided
        header('location: ../error.php');
    }

}
