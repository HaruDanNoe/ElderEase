<?php
include_once '../model/class.e.v.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'apply':
        new_event_application();
        break;
    case 'cancel':
        cancel_event_application();
        break;
}

function new_event_application()
{
    // Extract URL parameters
    $vp_id  = $_POST['vp_id'];
    $e_id   = $_POST['e_id'];

    $event_volunteer = new EventVolunteer();

    // Check if volunteer ID and event ID are provided
    if ($vp_id && $e_id) {
        // Apply for the event
        $result = $event_volunteer->new_event_application($vp_id, $e_id);

        if ($result) {
            // Redirect to a success page or back to the previous page
            header('Location: ../volunteer/event.php?e_id=' . $e_id . '&vp_id=' . $vp_id);
            exit();
        }
    }
} 

function cancel_event_application()
{
    $event_volunteer = new EventVolunteer();

    // Extract URL parameters
    $vp_id = isset($_GET['vp_id']) ? $_GET['vp_id'] : null; // Change from session to GET parameter
    $e_id = isset($_GET['e_id']) ? $_GET['e_id'] : null;

    // Check if volunteer ID and event ID are provided
    if ($vp_id && $e_id) {
        // Cancel the event application
        $result = $event_volunteer->cancel_event_application($vp_id, $e_id);

        if ($result) {
            // Redirect to a success page or back to the previous page
            header('Location: event.php?success=true');
            exit();
        } else {
            // Redirect to an error page
            header('Location: event.php?error=true');
            exit();
        }
    } else {
        // Redirect to an error page for missing IDs
        header('Location: event.php?missing_id=true');
        exit();
    }
}
?>
