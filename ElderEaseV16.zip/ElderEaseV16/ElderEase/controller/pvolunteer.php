<?php
include_once '../model/class.v.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch($action) {
    case 'new':
        new_volunteer();
        break;
    case 'update':
        update_volunteer();
        break;
    case 'deactivate':
        deactivate_volunteer();
        break;
    case 'delete':
        delete_volunteer();
        break;
}

function new_volunteer() {

    $volunteer = new Volunteer();
    
    $vp_name        = ucwords($_POST['vp_name']);
    $vp_phonenumber = ($_POST       ['vp_phonenumber']);
    $vp_email       = $_POST        ['vp_email'];
    $vp_password    = $_POST        ['vp_password'];
    $vp_status      = 0;
    
    // Hash the password
    $hashed_password = password_hash($vp_password, PASSWORD_DEFAULT);
    
    // Handle file upload
    $targetDirectory        = '../view/volunteer/vpbiodata/';
    $vpbiodataFilename      = basename($_FILES['vpbiodata']['name']);
    $targetFilePath         = $targetDirectory . $vpbiodataFilename;
    $fileType               = pathinfo($targetFilePath, PATHINFO_EXTENSION);

    // Check if file was uploaded without errors
    if (!empty($vpbiodataFilename)) {
        // Move uploaded file to target directory
        if (move_uploaded_file($_FILES['vpbiodata']['tmp_name'], $targetFilePath)) {
            // File uploaded successfully, insert file path into the database
            $result = $volunteer->new_volunteer($vp_name, $vp_phonenumber, $vp_email, $hashed_password, $vp_status, $targetFilePath);
            if ($result) {
                // Use JavaScript alert to display a success message
                echo "<script>alert('New volunteer added successfully.');</script>";
                // Redirect to index page
                header('location: ../index.php');
                exit(); // Stop further execution after redirect
            } else {
                // Handle database insertion error
                echo "<script>alert('Failed to insert record into the database.');</script>";
            }
        } else {
            // Error uploading file
            echo "<script>alert('Error uploading file.');</script>";
        }
    } else {
        // No file uploaded
        echo "<script>alert('No file uploaded.');</script>";
    }
}

function update_volunteer() {
    // Check if volunteer ID is provided
    if (!isset($_POST['vp_id'])) {
        // Redirect back if no volunteer ID is provided
        echo "<script>alert('Volunteer ID is missing.');</script>";
        header('location: ../index.php');
        exit(); // Stop further execution
    }

    // Create a new instance of the Volunteer class
    $volunteer = new Volunteer();

    // Extract form data
    $vp_id          = $_POST['vp_id'];
    $vp_name        = ucwords(trim($_POST['vp_name']));
    $vp_phonenumber = $_POST['vp_phonenumber'];
    $vp_email       = $_POST['vp_email'];
    $vp_password    = $_POST['vp_password']; // Password can also be updated if needed
    $vp_status      = $_POST['vp_status']; // Update status if necessary

    // Call the update_volunteer method of the Volunteer class to update volunteer information
    try {
        $result = $volunteer->update_volunteer($vp_name, $vp_phonenumber, $vp_email, $vp_password, $vp_status, $vp_id);

        // If volunteer update is successful, redirect to index page or any other relevant page
        if ($result) {
            // Use JavaScript alert to display a success message
            echo "<script>alert('Volunteer updated successfully.');</script>";
            header('location: ../index.php');
            exit(); // Stop further execution after redirect
        } else {
            // Handle update failure here, if needed
            echo "<script>alert('Failed to update volunteer. Please try again.');</script>";
        }
    } catch (PDOException $e) {
        // Log the error for debugging purposes
        error_log("Database error: " . $e->getMessage());

        // Display a user-friendly error message
        echo "<script>alert('Failed to update volunteer. Please try again later.');</script>";
    }
}

function deactivate_volunteer() {
    // Create a new instance of the Volunteer class
    $volunteer = new Volunteer();
    
    // Extract form data
    $vp_id = $_POST['vp_id']; 
    
    // Call the deactivate_volunteer method of the Volunteer class to deactivate the volunteer
    $result = $volunteer->deactivate_volunteer($vp_id);
    
    // If volunteer deactivation is successful, redirect to index page or any other relevant page
    if ($result) {
        // Use JavaScript alert to display a success message
        echo "<script>alert('Volunteer deactivated successfully.');</script>";
        header('location: ../index.php');
        exit(); // Stop further execution after redirect
    }
}

function delete_volunteer() {
    $volunteer = new Volunteer();
    $vp_id = isset($_GET['id']) ? $_GET['id'] : '';

    // Check if volunteer ID is provided
    if (!empty($vp_id)) {
        // Perform deletion
        $result = $volunteer->delete_volunteer($vp_id);

        // Redirect back to the page where the volunteer was deleted from
        header('location: ../index.php');
        exit(); // Stop further execution after redirect
    } else {
        // Redirect to a relevant error page if no volunteer ID is provided
        echo "<script>alert('Volunteer ID is missing.');</script>";
        header('location: ../error.php');
        exit(); // Stop further execution after redirect
    }
}
?>
