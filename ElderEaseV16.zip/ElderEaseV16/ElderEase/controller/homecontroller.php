<?php
class HomeController {
    // The index method is responsible for handling the default action of the controller
    public function index() {
        // Include the home.php view file when the index action is called
        include('view/header.php');
    }
}
?>
