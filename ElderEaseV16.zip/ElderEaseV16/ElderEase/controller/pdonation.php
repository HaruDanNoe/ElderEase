<?php
// Include the User class file
include '../model/class.donations.php';

// var_dump($_GET);
// exit();
// Check if 'action' parameter is set in the URL, if not, set it to an empty string
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Switch statement based on the value of 'action'
switch($action){
    // If action is 'new', call the function create_new_user()
    case 'new':
        new_donation();
    break;
    case 'update':
        update_donation();
    break;
    case 'delete':
        delete_event();
    break;
}

function new_donation() {

    $donations = new Donations();
    
    // Extract form data
    $d_name         = ucwords($_POST['d_name']);
    $d_email        = $_POST['d_email'];
    $d_phonenumber  = $_POST['d_phonenumber'];
    $d_comment      = $_POST['d_comment'];
    $d_amount       = $_POST['d_amount'];
    $now            = $_POST['d_datetransaction'];
    // $d_pmethod      = $_POST['d_pmethod'];
    
    // Handle file upload
    $targetDirectory    = '../view/donate/receipt/'; // Specify the target directory for storing receipt files
    $receiptFilename    = basename($_FILES['d_pmethod']['name']);
    $targetFilePath     = $targetDirectory . $receiptFilename;
    $fileType           = pathinfo($targetFilePath, PATHINFO_EXTENSION);

    // Check if file was uploaded without errors
    if (!empty($receiptFilename)) {
        // Move uploaded file to target directory
        if (move_uploaded_file($_FILES['d_pmethod']['tmp_name'], $targetFilePath)) {
            // File uploaded successfully, insert file path into the database
            $result = $donations->new_donation($d_name, $d_email, $d_phonenumber, $d_comment, $d_amount, $targetFilePath);
            if ($result) {
                // Use JavaScript alert to display a success message
                echo "<script>alert('Donation submitted successfully.');</script>";
                // Redirect to thank you page
                header('location: ../view/donate/thankyou.php'); 
            } else {
                // Handle database insertion error
                echo "<script>alert('Failed to insert record into the database.');</script>";
            }
        } else {
            // Error uploading file
            echo "<script>alert('Error uploading file.');</script>";
        }
    } else {
        // No file uploaded
        echo "<script>alert('No file uploaded.');</script>";
    }
}





function update_donation(){
    // Create a new instance of the User class
    $user = new User();
    
    // Extract form data
    $user_id = $_POST['userid'];
    $lastname = ucwords($_POST['lastname']);
    $firstname = ucwords($_POST['firstname']);
    $access = ucwords($_POST['access']);
    
    // Call the update_user method of the User class to update user information
    $result = $user->update_user($lastname,$firstname,$access,$user_id);
    
    // If user update is successful, redirect to user profile page
    if($result){
        // Redirect to the user profile page with the user ID in the URL
        header('location: ../finance/index.php?action=profile&id='.$user_id);
    }
}

    
    
    
function delete_event(){
        $events = new Event();
        $event_id = isset($_GET['id']) ? $_GET['id'] : '';
    
        // Check if user ID is provided
        if(!empty($event_id)) {
            // Perform deletion
            $result = $events->delete_event($event_id);
            
            // Redirect back to the page where the user was deleted from
            header('location: ../admin/event.php');
        } else {
            // Redirect to a relevant error page if no user ID is provided
            header('location: ../error.php');
        }
    
}

?>
