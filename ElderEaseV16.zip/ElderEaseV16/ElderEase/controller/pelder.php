<?php
// Include the User class file
include '../model/class.elder.php';

// var_dump($_GET);
// exit();
// Check if 'action' parameter is set in the URL, if not, set it to an empty string
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Switch statement based on the value of 'action'
switch($action){
    // If action is 'new', call the function create_new_user()
    case 'new':
        create_new_elder();
    break;
    case 'update':
        update_elder();
    break;
    case 'delete':
        delete_elder();
    break;
}

// Function to create a new user
function create_new_elder(){
    // Create a new instance of the Elder class
    $elder = new Elder();
    
    // Extract form data
    $p_fullname         = $_POST['p_fullname'];
    $p_gender           = ucwords($_POST['p_gender']);
    $p_age              = ucwords($_POST['p_age']);
    $p_birthday         = ucwords($_POST['p_birthday']);
    $p_status           = $_POST['p_status'];
    $p_medicalhistory   = $_POST['p_medicalhistory'];

    // Call the new_elder method of the Elder class to create a new elder
    $result = $elder->new_elder($p_fullname, $p_gender, $p_age, $p_birthday, $p_status, $p_medicalhistory);
    
    
    // If elder creation is successful, redirect to the profile page
    if($result){
        // Get the ID of the newly created elder
        // Assuming your Elder class has a method to retrieve the last inserted ID, you would do something like this:
       // $ElderId = $elder->getLastInsertedId();
        
        // Redirect to the elder profile page with the elder ID in the URL
        header('location: ../volunteer/index.php?action=profile&id='.$p_id);
    }
}

function get_elder($p_id){
    $sql="SELECT * FROM tbl_patients WHERE p_id = :p_id";	
    $q = $this->conn->prepare($sql);
    $q->execute(['p_id' => $p_id]);
    while($r = $q->fetch(PDO::FETCH_ASSOC)){
        $data[]=$r;
    }
    if(empty($data)){
       return false;
    }else{
        return $data;	
    }
}



function update_elder(){

    if (!isset($_POST['p_id'])) {

        // var_dump($p_id);
        // If user ID is not provided, redirect back to the admin page
        header('location: ../admin/index.php');
        exit(); // Stop further execution
    }
    // Create a new instance of the Elder class
    $elder = new Elder();
    
    // Extract form data
    $p_fullname             = ucwords($_POST['p_fullname']);
    $p_gender               = ucwords($_POST['p_gender']);
    $p_age                  = $_POST['p_age'];
    $p_birthday             = $_POST['p_birthday'];
    $p_status               = $_POST['p_status'];
    $p_medicalhistory       = $_POST['p_medicalhistory'];
    $p_id                   = $_POST['p_id'];
    
    // Call the update_elder method of the Elder class to update elder information
    $result = $elder->update_elder($p_fullname, $p_gender, $p_age, $p_birthday, $p_status, $p_medicalhistory, $p_id);
    // If elder update is successful, redirect to elder profile page
    if($result){
        // Redirect to the elder profile page with the elder ID in the URL
        header('location: ../volunteer/index.php?action=profile&id='.$p_id);
    }
}

    
    
    
function delete_elder() {
    $elder = new Elder();
    $elder_id = isset($_GET['id']) ? $_GET['id'] : '';

    // Check if elder ID is provided
    if (!empty($p_id)) {
        // Perform deletion
        $result = $elder->delete_elder($p_id);
        
        // Redirect back to the page where the elder was deleted from
        header('location: ../volunteer/index.php');
    } else {
        // Redirect to a relevant error page if no elder ID is provided
        header('location: ../error.php');
    }
}

    

