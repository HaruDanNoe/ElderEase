<?php
// Include the User class file
include '../model/class.event.php';

// var_dump($_GET);
// exit();
// Check if 'action' parameter is set in the URL, if not, set it to an empty string
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Switch statement based on the value of 'action'
switch($action){
    // If action is 'new', call the function create_new_user()
    case 'new':
        create_new_event();
    break;
    case 'update':
        update_event();
    break;
    case 'delete':
        delete_event();
    break;
}

function create_new_event(){

    $events = new Event();

    // Extract form data
    $e_date        = $_POST['e_date'];
    $e_stime       = $_POST['e_stime'];
    $e_etime       = $_POST['e_etime'];
    $e_description = $_POST['e_description'];
    
    // Call the new_event method of the Event class to create a new event
    $result = $events->new_event($e_date, $e_stime, $e_etime, $e_description);
    
    // If event creation is successful, redirect to event list page
    if($result === '') {
        header('location: ../admin/event.php');
    } else if($result === '23000') {
        // If duplicate entry, redirect with error message
        header('location: ../admin/event.php?error=duplicate');
    } else {
        // Handle other errors here
        header('location: ../admin/event.php?error=unknown');
    }
}


    
function delete_event(){
    $events = new Event();
    $event_id = isset($_GET['id']) ? $_GET['id'] : '';
    
    // Check if event ID is provided
    if(!empty($event_id)) {
        // Perform deletion
        $result = $events->delete_event($event_id);
        
        // Redirect back to the event list page
        header('location: ../admin/event.php');
    } else {
        // Redirect to a relevant error page if no event ID is provided
        header('location: ../error.php');
    }
}

