<?php
include '../model/class.donations.php';
$donations = new Donations();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance</title>
    <link rel="icon" type="image/x-icon" href="../img/icon/favicon.ico">
    <link href="../css/style.css" rel="stylesheet" type="text/css">
    <style>
        .invoice-box {
            top: 100px;
            max-width: 800px;
            margin: 20px auto 20px;
            padding: 100px;
            background-color: #fff;
            border-radius: 8px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);

        }
        nav{
            margin-bottom: 220px; 
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        .move-right {
            float: right;
            margin-top: -40px;
        }

        .button {
            padding: 8px 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<header class="header">
    <nav class="navi">
        <h1 class="navi-logo">Finance</h1>
        <a href="../logout.php" class="navv">Log Out</a>
    </nav>
</header>

<div class="invoice-box">
    <h1>Donations</h1>
    <table id="data-list">
        <tr>
            <th>Name</th>
            <th>Donations</th>
            <th>Receipt</th>
        </tr>
        <?php
        $count = 1;
        if ($donations->list_donations() != false) {
            foreach ($donations->list_donations() as $value) {
                extract($value);
                ?>
                <tr>
                    <td><?php echo $d_name; ?></td>
                    <td><?php echo $d_amount; ?></td>
                 <!--   <td><?php echo $d_pmethod; ?></td> -->
                    <td>
                        <?php 
                        // Display a download link for the file
                        echo "<a href='$d_pmethod' target='_blank'>Download</a>";
                        ?>
                    </td>
                </tr>
                <?php
                $count++;
            }
        } else {
            echo "<tr><td colspan='3'>No Record Found.</td></tr>";
        }
        ?>
    </table>
</div>
</body>
</html>
