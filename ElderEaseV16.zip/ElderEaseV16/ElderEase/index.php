<?php
include('view/header.php');
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ElderEase</title>
    <link rel="icon" type="image/x-icon" href="img/icon/favicon.ico">
    <link href="css/style.css" rel="stylesheet" type="text/css"<?php echo time();?>>

</head>
<body>




</body>
</html>
<?php
include('view/footer.php');
?>