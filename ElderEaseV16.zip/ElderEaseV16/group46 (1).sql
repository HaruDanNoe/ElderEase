-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2024 at 06:34 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `group46`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_donation`
--

CREATE TABLE `tbl_donation` (
  `d_id` int(11) NOT NULL,
  `d_name` varchar(100) DEFAULT NULL,
  `d_email` varchar(100) DEFAULT NULL,
  `d_phonenumber` varchar(20) DEFAULT NULL,
  `d_comment` varchar(250) DEFAULT NULL,
  `d_amount` decimal(10,2) DEFAULT NULL,
  `d_pmethod` varchar(250) DEFAULT NULL,
  `d_datetransaction` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_donation`
--

INSERT INTO `tbl_donation` (`d_id`, `d_name`, `d_email`, `d_phonenumber`, `d_comment`, `d_amount`, `d_pmethod`, `d_datetransaction`) VALUES
(11, 'Meg', 'meg@gmail.com', '0989859595', 'ajhdajdjadjadh', 800.00, '../view/donate/receipt/429131121_417478277308911_458560648672391704_n.jpg', '2024-03-12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_event`
--

CREATE TABLE `tbl_event` (
  `e_id` int(11) NOT NULL,
  `e_date` date DEFAULT NULL,
  `e_stime` time DEFAULT NULL,
  `e_etime` time DEFAULT NULL,
  `e_description` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_event`
--

INSERT INTO `tbl_event` (`e_id`, `e_date`, `e_stime`, `e_etime`, `e_description`) VALUES
(25, '2003-02-15', '08:00:00', '09:00:00', 'Angel\'s Birthday');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_event_applications`
--

CREATE TABLE `tbl_event_applications` (
  `application_id` int(11) NOT NULL,
  `e_id` int(11) DEFAULT NULL,
  `vp_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_patients`
--

CREATE TABLE `tbl_patients` (
  `p_id` int(11) NOT NULL,
  `p_fullname` varchar(100) DEFAULT NULL,
  `p_gender` varchar(10) DEFAULT NULL,
  `p_age` int(11) DEFAULT NULL,
  `p_birthday` date DEFAULT NULL,
  `p_status` varchar(50) DEFAULT NULL,
  `p_medicalhistory` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_patients`
--

INSERT INTO `tbl_patients` (`p_id`, `p_fullname`, `p_gender`, `p_age`, `p_birthday`, `p_status`, `p_medicalhistory`) VALUES
(6, 'Adadadada', 'Kjekqkeqkw', 32356, '0000-00-00', 'adjajda', 'kjadjajdgja');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `user_fname` varchar(50) DEFAULT NULL,
  `user_lname` varchar(50) DEFAULT NULL,
  `user_gender` varchar(10) DEFAULT NULL,
  `user_age` int(11) DEFAULT NULL,
  `user_address` varchar(255) DEFAULT NULL,
  `user_phonenumber` varchar(20) DEFAULT NULL,
  `user_role` varchar(20) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `user_password` varchar(250) DEFAULT NULL,
  `user_confirmpassword` varchar(250) DEFAULT NULL,
  `user_date_added` date DEFAULT NULL,
  `user_time_added` time DEFAULT NULL,
  `user_status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_fname`, `user_lname`, `user_gender`, `user_age`, `user_address`, `user_phonenumber`, `user_role`, `user_email`, `user_password`, `user_confirmpassword`, `user_date_added`, `user_time_added`, `user_status`) VALUES
(6, 'ANlie', 'Wwf', 'female', 19, 'murcia', '0656262', 'Admin', 'E@gmail.com', '123', '123', '2024-03-08', '21:00:57', '1'),
(24, 'Precious', 'Endoma', 'FEmake', 18, 'Afafa', '09899898989', 'Finance', 'precious@gmail.com', '$2y$10$1dbWb5zeyW9wq35cLOch7.kaZqpd8E2M89Nl89laeFCvFcpbjZy2K', '$2y$10$DbvRa/SfcbhSc.0RXKuUVOLhy1b6oYYZRlXF7d6Hu1HYa32Px1ype', '2024-03-12', '13:18:43', NULL),
(25, 'Reddick', 'Ceballos', 'Male', 18, 'Murcia', '0989898989', 'Finance', 'rrr@gmail.com', '$2y$10$4pSyLBdJ40GrcWRWqHEt5eiaXsEJ.cdqx/bkwjEIBrp7ayGAYE.fG', '$2y$10$AwK5x6hxTJwyxiFuKX06zup6RUf3KFy2JnEZcDlO6TiVHj22as8DC', '2024-03-12', '12:13:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_volunteerapplication`
--

CREATE TABLE `tbl_volunteerapplication` (
  `vp_id` int(11) NOT NULL,
  `vp_name` varchar(100) DEFAULT NULL,
  `vp_email` varchar(100) DEFAULT NULL,
  `vp_password` varchar(250) DEFAULT NULL,
  `vp_phonenumber` varchar(11) DEFAULT NULL,
  `vp_biodata` varchar(250) DEFAULT NULL,
  `vp_status` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_volunteerapplication`
--

INSERT INTO `tbl_volunteerapplication` (`vp_id`, `vp_name`, `vp_email`, `vp_password`, `vp_phonenumber`, `vp_biodata`, `vp_status`) VALUES
(14, 'Akdwndnkdnd', 'ada@gmail.com', '123', '266466', '../view/volunteer/vpbiodata/More family puppets.pdf', 1),
(38, 'Akdwndnkdnd', 'qwer@gmail.com', '$2y$10$1sU7zZtg5n/fGLQywiOvfONW1BeIZVdYtqxiJBkFNLaXqAUKXiMFq', '5464979', '../view/volunteer/vpbiodata/file (1).pdf', 1),
(39, 'Angel', 'ngel@gmail.com', '$2y$10$/5Zq6YNMAm2Ncz7lsCV2HepjCJrSBXpfyCjBH/byC/fVHKc1Jssei', '04666565989', '../view/volunteer/vpbiodata/bleeh.pdf', 1),
(40, 'Angel', 'angel@gmail.com', '$2y$10$i2TmVsclen7xl1Q8GKxXkuMmHQjm9cqRpqxKUNatXH.NiP4HrNonG', '04666565989', '../view/volunteer/vpbiodata/file.pdf', 1),
(41, 'Kyrie', 'ea@gmail.com', '$2y$10$gFSUBWB7bGrj21J95LjBQeSn4bzs9u7S5oa6Xo9D8WtUU9wfV40Za', '09889895989', '../view/volunteer/vpbiodata/2.3.3 Assignment 1_ DB and Tables_Group#1.pdf', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_donation`
--
ALTER TABLE `tbl_donation`
  ADD PRIMARY KEY (`d_id`),
  ADD UNIQUE KEY `d_email` (`d_email`),
  ADD UNIQUE KEY `d_phonenumber` (`d_phonenumber`);

--
-- Indexes for table `tbl_event`
--
ALTER TABLE `tbl_event`
  ADD PRIMARY KEY (`e_id`),
  ADD UNIQUE KEY `e_stime` (`e_stime`),
  ADD UNIQUE KEY `unique_description_constraint` (`e_description`);

--
-- Indexes for table `tbl_event_applications`
--
ALTER TABLE `tbl_event_applications`
  ADD PRIMARY KEY (`application_id`),
  ADD UNIQUE KEY `vp_id` (`vp_id`),
  ADD KEY `tbl_event_applications_ibfk_1` (`e_id`);

--
-- Indexes for table `tbl_patients`
--
ALTER TABLE `tbl_patients`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_email` (`user_email`),
  ADD UNIQUE KEY `user_phonenumber` (`user_phonenumber`),
  ADD UNIQUE KEY `user_password` (`user_password`),
  ADD UNIQUE KEY `user_confirmpassword` (`user_confirmpassword`);

--
-- Indexes for table `tbl_volunteerapplication`
--
ALTER TABLE `tbl_volunteerapplication`
  ADD PRIMARY KEY (`vp_id`),
  ADD UNIQUE KEY `unique_password` (`vp_password`),
  ADD UNIQUE KEY `vp_email` (`vp_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_donation`
--
ALTER TABLE `tbl_donation`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_event`
--
ALTER TABLE `tbl_event`
  MODIFY `e_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_event_applications`
--
ALTER TABLE `tbl_event_applications`
  MODIFY `application_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tbl_patients`
--
ALTER TABLE `tbl_patients`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_volunteerapplication`
--
ALTER TABLE `tbl_volunteerapplication`
  MODIFY `vp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_event_applications`
--
ALTER TABLE `tbl_event_applications`
  ADD CONSTRAINT `tbl_event_applications_ibfk_1` FOREIGN KEY (`e_id`) REFERENCES `tbl_event` (`e_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tbl_event_applications_ibfk_2` FOREIGN KEY (`vp_id`) REFERENCES `tbl_volunteerapplication` (`vp_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
